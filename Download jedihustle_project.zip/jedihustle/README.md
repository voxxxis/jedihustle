# JediHustle

Autonomous AI business agent.

## Setup Instructions
1. Add your API keys to `.env`
2. Run `main.py`
