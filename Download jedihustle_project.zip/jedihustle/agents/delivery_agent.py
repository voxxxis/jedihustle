# Handles delivery of services
