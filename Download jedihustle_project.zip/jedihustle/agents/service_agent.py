# Handles service execution
