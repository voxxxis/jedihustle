# Handles client communication
